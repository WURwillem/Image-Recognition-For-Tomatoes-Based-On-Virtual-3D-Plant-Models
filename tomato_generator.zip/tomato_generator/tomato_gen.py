import sys
import bpy
import numpy as np
import re
import json
from pathlib import Path
import argparse


parser = argparse.ArgumentParser()
parser.add_argument('-o', '--model_dir', dest='model_dir',
                    default='generated/test_tomato')
parser.add_argument('-s', '--seed', dest='seed', type=int, default=np.random.randint(10000))


if '--' in sys.argv:
    argv = sys.argv[sys.argv.index('--') + 1:]
else:
    argv = []
args = parser.parse_known_args(argv)[0]

np.random.seed(args.seed)

bpy.ops.object.select_all(action='DESELECT')

model_dir = Path(args.model_dir)
model_dir.mkdir(parents=True, exist_ok=True)

"""
Based on the following parameters a tomato plant is generated. It consists of a randomized main stem that is build up
from several nodes that are stacked on top of each other. Then, at the end of each node, which is also the start of
the next one, one of a preexisting list of side branches is attached.
"""
avg_node_length =0.05 #average node length
sd_node_length = 0.01 #standard deviation of node height
avg_node_count = 15 #nodes are places in the stem where a branch can appear
sd_node_count = 3 #standard deviation of node count

first_node_multiplication_factor = 3 #the first node can be longer to simulate stretching fase, also avoids certain side
                                     #branches that might be attached to hang below the ground.

DIV = 15 #amount of edges the main stem has(if 3 -> stem triangle shaped, if 6 -> stem is a hexagon)
avg_radius = 0.015 #average radius of the first node
sd_radius = 0.001 #sd of the radius of the first node
node_radius_reduction = 0.5 #the reduction factor of how fast the stem becomes narrower towards the top

lower_section_cutoff = 5 #the lower section of the plant contains only larger low_leaves
sd_lower_section_cutoff = 1
middle_section_cutoff = 11 #the middle section contains both tomatoes and leaves, the upper leaves and flowers
sd_middle_section_cutoff = 1
chance_tomato_or_flower = 0.4 #the chance that a node in the middle or upper section contains fruits or flowers


class Node:
    def __init__(self, x, y, z, yaw, r):
        """
        xyz are the start coordinates of a node
        yaw is the angle a node is directed towards
        r is the radius of a node (starts at about 0.01 and becomes smaller to the top)
        """
        self.x = x
        self.y = y
        self.z = z
        self.yaw = yaw
        self.r = r

def gen_nodes(avg_node_length, sd_node_length, avg_node_count, sd_node_count):
    """
    Based on the input variables a list of z coordinates (heights) for the nodes is created
    """
    node_heights = []
    node_count = round(np.random.normal(avg_node_count, sd_node_count))
    last_node = 0
    for i in range(node_count):
        new_node = last_node + np.random.normal(avg_node_length, sd_node_length)
        if i ==0:
            new_node = new_node * first_node_multiplication_factor  #make the first node x times as long as the others
        node_heights.append(new_node)
        last_node = new_node

    """
    Then, the other parameters of the node are added. The first node is added before the loop, since this one does not
    rotate.
    """
    r_start = np.random.normal(avg_radius, sd_radius) #Radius of the first node
    nodes = [Node(0, 0, 0, 0, r_start)]  #The first node start at xyz 0,0,0 and goes straight up (direction = 0)
    height_plant = node_heights[-1] #the last node determines the height of the plant

    for z in node_heights:
        prev = nodes[-1]
        yaw = prev.yaw + (np.pi * (2.0/3.0) + np.random.normal(0, 0.4))
        step_up = z - prev.z
        y = np.sin(yaw) * (step_up/15.0)
        x = np.cos(yaw) * (step_up/15.0)
        r = np.random.normal(avg_radius, sd_radius) * (1-node_radius_reduction*(z/height_plant))
        nodes.append(Node(x, y, z, yaw, r))

    return nodes

def create_ring_verts(node):
    """
    Ring vertices are created based on the DIV variable and parameters of the node
    DIV = 4 -> stem is square
    DIV = 6 - > stem is a hexagon
    """
    verts = []
    for i in range(DIV):
        a = (np.pi*2) * (i/DIV)
        x = node.x + np.cos(a) * node.r
        y = node.y + np.sin(a) * node.r
        verts.append((x, y, node.z))
    return verts

def gen_main_stem(collection):
    """
    The main stem 3d model is generated here. First it uses the gen_nodes function that was previously defined.
    """
    verts = []
    faces = []
   
    nodes = gen_nodes(avg_node_length, sd_node_length, avg_node_count, sd_node_count)

    prev_ring = create_ring_verts(nodes[0])
    verts = verts + prev_ring

    for node in nodes[1:]:
        vert_start = len(verts) - DIV
        ring = create_ring_verts(node)
        verts = verts + ring
        prev_ring = ring

        for i in range(DIV):
            vi = vert_start + i
            vip = vert_start + ((i+1) % DIV)
            faces.append((vi, vip, vip+DIV, vi+DIV))

    #close main stem by placing conical shape on the last node
    last_ring_start = len(verts) - DIV
    verts.append((nodes[-1].x, nodes[-1].y, nodes[-1].z + 0.01))
    for i in range(DIV):
        vi = last_ring_start + i
        vip = last_ring_start + ((i+1) % DIV)
        faces.append((vi, vip, len(verts)-1))


    #Define mesh and object
    mesh = bpy.data.meshes.new("Branch1")

    #Create mesh
    mesh.from_pydata(verts, [], faces)
    mesh.update(calc_edges=True)

    object = bpy.data.objects.new("Branch1", mesh)

    collection.objects.link(object)

    mat = bpy.data.materials.get("Branch1")
    object.data.materials.append(mat)

    return object, nodes



# Generate leaf, fruit, and flower formations

def filter_prefix(objects, prefix):
    """
    This is a simple function that is only added to improve readability
    """
    return list(
        filter(lambda ob: ob.name.startswith(prefix), objects))

class PrebuiltMeshes:
    def __init__(self):
        objects = bpy.data.collections['sub_stems'].all_objects #objects are loaded in
        self.sub_stems = filter_prefix(objects, 'b_')
        print("selfsubstems:", self.sub_stems)

    def get_end_stem_mesh(self, growth, node_nr):
        """
        A side branch needs to be selected. There are different types that can be seen in the visualisation.
        """
        # (Why is b_07 not included in the original script? I followed this, but I don't see why it cant be added.)
        low_leaves = ['b_04_01','b_04_02','b_04_03','b_04_04','b_04_05','b_05_01','b_05_02','b_05_03','b_05_04','b_05_05','b_05_06','b_05_07','b_05_08','b_05_09','b_05_10','b_05_11','b_05_12','b_05_13','b_05_14','b_06_01','b_06_02','b_06_03','b_06_04','b_06_05','b_08_01','b_08_02','b_08_03','b_08_04','b_08_05','b_08_06']
        tomato_branches = ['b_04_06', 'b_04_07', 'b_04_08', 'b_05_16', 'b_05_17', 'b_06_06', 'b_06_07', 'b_06_08', 'b_06_09', 'b_08_07', 'b_08_08', 'b_08_09', 'b_08_10']
        nr_tomatoes = [4,4,5,6,5,5,5,4,4,5,6,5,8] #parameter not used, but gives the amount of tomatoes for each entry in tomato_branches
        leaves = ['b_05_18','b_05_19','b_05_20','b_05_21','b_05_22']
        flowers = ['b_04_09','b_04_10','b_04_11','b_04_12','b_04_13','b_04_14','b_04_15','b_04_16','b_04_17','b_04_18','b_05_23','b_06_10','b_06_11','b_06_12','b_06_13','b_06_14','b_06_15','b_06_16','b_06_17','b_06_18','b_06_19','b_08_11','b_08_12','b_08_13','b_08_14','b_08_15','b_08_16']
        small_leave = ['b_04_19','b_06_20','b_08_17']

        #Determine section cutoffs
        current_lower_section_cutoff = round(np.random.normal(lower_section_cutoff, sd_lower_section_cutoff))
        current_middle_section_cutoff = round(np.random.normal(middle_section_cutoff, sd_middle_section_cutoff))

        #Depending on height, a sidebranch is selected
        if node_nr < current_lower_section_cutoff:
            prefix = low_leaves[np.random.choice(len(low_leaves))]
        elif node_nr < current_middle_section_cutoff:
            random_val = np.random.rand()
            if random_val > chance_tomato_or_flower:
                prefix = leaves[np.random.choice(len(leaves))]
            else:
                prefix = tomato_branches[np.random.choice(len(tomato_branches))]
        else:
            random_val = np.random.rand()
            if random_val > chance_tomato_or_flower:
                prefix = leaves[np.random.choice(len(leaves))]
            else:
                prefix = flowers[np.random.choice(len(flowers))]

        stems = filter_prefix(self.sub_stems, prefix)

        # Growths are the z coordinates of the samples in the collections. They are floating in the air in blender.
        # These are then divided by the highest z coordinate
        growths = np.array(list(map(lambda ob: ob.location[2], stems)))
        growths = growths / np.max(growths)
        idx_options = np.argsort(np.abs(growths - growth))[:5] #is always 0?
        print("idx:", idx_options)
        return stems[np.random.choice(idx_options)]

prebuilt_meshes = PrebuiltMeshes()

def gen_end_stem(collection, location: (float, float, float), yaw: float, growth: float, node_nr):
    """
    Here a side branch is added as an object that looks like this: <bpy_struct, Object("b_05_21.002")>
    I'd recommend to not touch this function, random selection of side branches occurs elsewhere.
    """
    coll_sub_stems = bpy.data.collections['sub_stems']
    ob_stem = prebuilt_meshes.get_end_stem_mesh(growth,node_nr)
    ob_fruits = filter_prefix(ob_stem.children, 'pose_fruit')
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.object.duplicate({
        'selected_objects': [ob_stem] + ob_fruits,
        'active_object': ob_stem
    })
    ob_stem = filter_prefix(bpy.context.selected_objects, 'b_')[0]
    ob_fruits = filter_prefix(ob_stem.children, 'pose_fruit')
    
    ob_stem.select_set(False)
    if location is not None:
        ob_stem.location = location
    if yaw is not None:
        ob_stem.rotation_euler[2] += yaw #Here the euler rotation of the z axis is changed bij adding the yaw.

    collection.objects.link(ob_stem)
    coll_sub_stems.objects.unlink(ob_stem)
    for ob in ob_fruits:
        collection.objects.link(ob)
        coll_sub_stems.objects.unlink(ob)

    return ob_stem, ob_fruits

def gen_plant(write_results=False, keep_materials=False):
    """
    This function combines all previous functions
    """
    collection = bpy.data.collections.new('new_plant')
    bpy.context.scene.collection.children.link(collection)

    ob_main_stem, nodes = gen_main_stem(collection)

    ob_meshes = [ob_main_stem]
    ob_fruits = []

    for i in range(1,len(nodes)):
        node = nodes[i]
        ob_m, ob_f = gen_end_stem(collection, location=(node.x, node.y, node.z), yaw=node.yaw,
                                  growth=node.z / nodes[-1].z, node_nr=i)
        ob_meshes.append(ob_m)
        ob_fruits += ob_f

    markers = []


    def add_marker(location, type='FRUIT'):
        marker = {
            'marker_type': type,
            'translation': [location[0], location[1], location[2]],
        }
        markers.append(marker)


    for ob in ob_fruits:
        bpy.ops.object.parent_clear(
            {'selected_objects': [ob]}, type='CLEAR_KEEP_TRANSFORM')
        add_marker(ob.location)
        bpy.ops.object.delete({'selected_objects': [ob]}, use_global=True)

    bpy.ops.object.join({
        'selected_objects': ob_meshes,
        'selected_editable_objects': ob_meshes,
        'active_object': ob_meshes[0]
    })

    ob_merged = collection.objects[0]

    bpy.ops.mesh.separate({
        'selected_editable_objects': [ob_merged]
    }, type='MATERIAL')

    bpy.ops.object.select_all(action='DESELECT')
    for ob in collection.all_objects:
        # name the mesh
        ob.name = ob.material_slots[0].material.name
        # remove the material (it will be added in the SDF file)
        if not keep_materials:
            ob.data.materials.clear()
        # select for the export
        ob.select_set(True)

    if write_results:
        bpy.ops.wm.collada_export(filepath=str(
            model_dir / 'meshes/tomato.dae'), check_existing=True, selected=True)

        with open(model_dir / 'markers.json', 'w') as outfile:
            json.dump(markers, outfile, indent=4)
        bpy.ops.object.delete(use_global=True)

    return collection

if __name__ == '__main__':
    gen_plant(write_results=True)